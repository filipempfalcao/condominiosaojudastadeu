import sys
import os

# Adicionar diretório do projeto ao path
path = '/home/seu_usuario/mysite'
if path not in sys.path:
    sys.path.append(path)

# Configurar variáveis de ambiente
os.environ['FLASK_ENV'] = 'production'
os.environ['SECRET_KEY'] = 'sua-chave-secreta-aqui'
os.environ['GOOGLE_CREDENTIALS_FILE'] = 'credentials.json'
os.environ['SPREADSHEET_NAME'] = 'Condominio_Sao_Judas_Tadeu'
os.environ['FRONTEND_URL'] = 'https://filipempfalcao.github.io/condominiosaojudastadeu'

# Importar a aplicação
from app import create_app
application = create_app()
