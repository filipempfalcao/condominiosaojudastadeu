# Backend - Site de Controle de Demandas do Condomínio

Este diretório contém os arquivos do backend para o site de controle de demandas do condomínio.

## Estrutura de Arquivos

- `app.py` - Ponto de entrada da aplicação
- `wsgi.py` - Arquivo de configuração WSGI para PythonAnywhere
- `app/` - Diretório da aplicação Flask
  - `__init__.py` - Inicialização da aplicação
  - `auth/` - Módulo de autenticação
  - `demandas/` - Módulo de demandas
  - `dashboard/` - Módulo de dashboard
  - `database/` - Módulo de banco de dados

## Configuração

O backend está configurado para se comunicar com o frontend através de uma API RESTful. A autenticação é feita usando JWT (JSON Web Tokens).

## Implantação no PythonAnywhere

1. Crie uma conta no PythonAnywhere
2. Faça upload de todos os arquivos deste diretório para o PythonAnywhere
3. Configure uma nova aplicação web:
   - Escolha Flask como framework
   - Configure o caminho para o arquivo WSGI (`/home/seu_usuario/mysite/wsgi.py`)
   - Configure o ambiente virtual
4. Faça upload do arquivo de credenciais do Google Sheets
5. Configure as variáveis de ambiente no arquivo `wsgi.py`

## Endpoints da API

### Autenticação

- `POST /api/auth/login` - Login de usuário
- `POST /api/auth/register` - Registro de novo usuário
- `GET /api/auth/me` - Informações do usuário autenticado

### Demandas

- `GET /api/demandas` - Listar demandas
- `GET /api/demandas/<id>` - Obter detalhes de uma demanda
- `POST /api/demandas` - Criar nova demanda
- `PUT /api/demandas/<id>` - Atualizar demanda
- `DELETE /api/demandas/<id>` - Excluir demanda

### Dashboard

- `GET /api/dashboard/indicadores` - Obter indicadores do dashboard
- `GET /api/dashboard/grafico_unificado` - Obter dados do gráfico unificado

## Comunicação com o Frontend

O backend se comunica com o frontend através de chamadas de API. Certifique-se de que o frontend esteja configurado para acessar a URL correta do backend.
