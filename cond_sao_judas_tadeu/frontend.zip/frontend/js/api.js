/**
 * API para comunicação com o backend
 */

const API_URL = "https://seu-usuario.pythonanywhere.com/api";

// Função para obter token de autenticação
function getAuthToken() {
    return localStorage.getItem('auth_token');
}

// Função para definir token de autenticação
function setAuthToken(token) {
    localStorage.setItem('auth_token', token);
}

// Função para remover token de autenticação
function removeAuthToken() {
    localStorage.removeItem('auth_token');
}

// Função para verificar se o usuário está autenticado
function isAuthenticated() {
    return !!getAuthToken();
}

// Função para fazer login
async function login(email, senha) {
    try {
        const response = await fetch(`${API_URL}/auth/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email, senha })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            setAuthToken(data.token);
            return { success: true };
        } else {
            return { success: false, message: data.message || 'Erro ao fazer login' };
        }
    } catch (error) {
        console.error('Erro ao fazer login:', error);
        return { success: false, message: 'Erro de conexão' };
    }
}

// Função para fazer logout
function logout() {
    removeAuthToken();
    window.location.href = 'login.html';
}

// Função para registrar novo usuário
async function register(nome, email, senha) {
    try {
        const response = await fetch(`${API_URL}/auth/register`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ nome, email, senha })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            return { success: true };
        } else {
            return { success: false, message: data.message || 'Erro ao registrar' };
        }
    } catch (error) {
        console.error('Erro ao registrar:', error);
        return { success: false, message: 'Erro de conexão' };
    }
}

// Função para obter lista de demandas
async function getDemandas(filtros = {}) {
    try {
        const token = getAuthToken();
        if (!token) return { success: false, message: 'Não autenticado' };
        
        // Construir query string com filtros
        const queryParams = new URLSearchParams();
        Object.keys(filtros).forEach(key => {
            if (filtros[key]) queryParams.append(key, filtros[key]);
        });
        
        const response = await fetch(`${API_URL}/demandas?${queryParams}`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        const data = await response.json();
        
        if (response.ok) {
            return { success: true, demandas: data.demandas, total_pages: data.total_pages };
        } else {
            return { success: false, message: data.message || 'Erro ao obter demandas' };
        }
    } catch (error) {
        console.error('Erro ao obter demandas:', error);
        return { success: false, message: 'Erro de conexão' };
    }
}

// Função para obter detalhes de uma demanda
async function getDemanda(id) {
    try {
        const token = getAuthToken();
        if (!token) return { success: false, message: 'Não autenticado' };
        
        const response = await fetch(`${API_URL}/demandas/${id}`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        const data = await response.json();
        
        if (response.ok) {
            return { success: true, demanda: data.demanda };
        } else {
            return { success: false, message: data.message || 'Erro ao obter demanda' };
        }
    } catch (error) {
        console.error(`Erro ao obter demanda ${id}:`, error);
        return { success: false, message: 'Erro de conexão' };
    }
}

// Função para criar nova demanda
async function criarDemanda(demanda) {
    try {
        const token = getAuthToken();
        if (!token) return { success: false, message: 'Não autenticado' };
        
        const response = await fetch(`${API_URL}/demandas`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify(demanda)
        });
        
        const data = await response.json();
        
        if (response.ok) {
            return { success: true, demanda: data.demanda };
        } else {
            return { success: false, message: data.message || 'Erro ao criar demanda' };
        }
    } catch (error) {
        console.error('Erro ao criar demanda:', error);
        return { success: false, message: 'Erro de conexão' };
    }
}

// Função para atualizar demanda
async function atualizarDemanda(id, demanda) {
    try {
        const token = getAuthToken();
        if (!token) return { success: false, message: 'Não autenticado' };
        
        const response = await fetch(`${API_URL}/demandas/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify(demanda)
        });
        
        const data = await response.json();
        
        if (response.ok) {
            return { success: true, demanda: data.demanda };
        } else {
            return { success: false, message: data.message || 'Erro ao atualizar demanda' };
        }
    } catch (error) {
        console.error(`Erro ao atualizar demanda ${id}:`, error);
        return { success: false, message: 'Erro de conexão' };
    }
}

// Função para excluir demanda
async function excluirDemanda(id) {
    try {
        const token = getAuthToken();
        if (!token) return { success: false, message: 'Não autenticado' };
        
        const response = await fetch(`${API_URL}/demandas/${id}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        const data = await response.json();
        
        if (response.ok) {
            return { success: true };
        } else {
            return { success: false, message: data.message || 'Erro ao excluir demanda' };
        }
    } catch (error) {
        console.error(`Erro ao excluir demanda ${id}:`, error);
        return { success: false, message: 'Erro de conexão' };
    }
}

// Função para obter dados do dashboard
async function getDashboardData(periodo = 'ultimos_30_dias') {
    try {
        const token = getAuthToken();
        if (!token) return { success: false, message: 'Não autenticado' };
        
        // Obter indicadores
        const indicadoresResponse = await fetch(`${API_URL}/dashboard/indicadores?periodo=${periodo}`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        const indicadoresData = await indicadoresResponse.json();
        
        // Obter dados do gráfico
        const graficoResponse = await fetch(`${API_URL}/dashboard/grafico_unificado?periodo=${periodo}`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        const graficoData = await graficoResponse.json();
        
        if (indicadoresResponse.ok && graficoResponse.ok) {
            return {
                success: true,
                indicadores: indicadoresData,
                grafico: graficoData
            };
        } else {
            return { 
                success: false, 
                message: indicadoresData.message || graficoData.message || 'Erro ao obter dados do dashboard' 
            };
        }
    } catch (error) {
        console.error('Erro ao obter dados do dashboard:', error);
        return { success: false, message: 'Erro de conexão' };
    }
}
