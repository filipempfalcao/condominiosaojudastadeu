# Frontend - Site de Controle de Demandas do Condomínio

Este diretório contém os arquivos estáticos do frontend para o site de controle de demandas do condomínio.

## Estrutura de Arquivos

- `index.html` - Página inicial (redirecionamento para demandas)
- `login.html` - Página de login
- `register.html` - Página de registro
- `demandas.html` - Listagem de demandas
- `nova-demanda.html` - Formulário de nova demanda
- `detalhes.html` - Detalhes da demanda
- `dashboard.html` - Dashboard com gráficos e indicadores

## Diretórios

- `css/` - Arquivos de estilo
- `js/` - Scripts JavaScript
- `images/` - Imagens

## Configuração

O frontend está configurado para se comunicar com o backend através da API. A URL base da API está definida no arquivo `js/api.js`.

## Implantação

Para implantar o frontend no GitHub Pages:

1. Crie um repositório no GitHub
2. Faça upload de todos os arquivos deste diretório para o repositório
3. Ative o GitHub Pages nas configurações do repositório
4. Selecione a branch principal como fonte para o GitHub Pages

## Comunicação com o Backend

O frontend se comunica com o backend através de chamadas de API. Certifique-se de que o backend esteja configurado e acessível antes de usar o frontend.
