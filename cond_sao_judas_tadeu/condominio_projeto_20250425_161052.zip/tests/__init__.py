"""
Arquivo de inicialização para o pacote de testes.
"""

# Este arquivo está vazio intencionalmente, mas é necessário para que o Python reconheça
# este diretório como um pacote e permita a importação de módulos.
